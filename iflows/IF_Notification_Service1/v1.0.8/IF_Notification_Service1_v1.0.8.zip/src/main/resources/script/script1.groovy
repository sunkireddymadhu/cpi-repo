import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // Get body created from previous flow
    def body = message.getBody(String)

    // Optional: create subject
    def subject = "[CPI ALERT] Interface Failure Notification"

    // Set subject property for Mail adapter
    message.setProperty("MailSubject", subject)

    // Body remains the same
    message.setBody(body)

    return message
}