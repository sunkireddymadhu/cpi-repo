import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // =====================================================
    // 1. EXCEPTION EXTRACTION (UNWRAP ROOT CAUSE SAFELY)
    // =====================================================
    def ex = message.getProperty("CamelExceptionCaught")

    def root = ex
    int depth = 0

    while (root?.getCause() != null && depth < 10) {
        root = root.getCause()
        depth++
    }

    def exClass = root?.getClass()?.getName()?.toLowerCase()
    def exMsg   = root?.getMessage()?.toLowerCase()

    // =====================================================
    // 2. DEVELOPER PREFERENCES
    // =====================================================
    boolean devRetry   = message.getProperty("IsRetry")   == true
    boolean devNotify  = message.getProperty("IsNotify")  == true
    boolean devTicket  = message.getProperty("IsTicket")  == true
    boolean devPersist = message.getProperty("IsPersist") == true

    // =====================================================
    // 3. FRAMEWORK DECISION FLAGS
    // =====================================================
    boolean allowRetry   = false
    boolean forceNotify  = false
    boolean forceTicket  = false
    boolean forcePersist = false

    if (root != null) {

        // -------------------------------------------------
        // TRANSIENT / CONNECTIVITY ERRORS → RETRY ALLOWED
        // -------------------------------------------------
        if (
            exClass?.contains("timeout") ||
            exClass?.contains("connect") ||
            exClass?.contains("unknownhost") ||
            exClass?.contains("ssl")
        ) {
            allowRetry = true
        }

        // -------------------------------------------------
        // HTTP ERRORS
        // -------------------------------------------------
        else if (exClass?.contains("httpoperationfailed")) {

            def match = (exMsg =~ /\b\d{3}\b/)
            if (match) {
                try {
                    int code = match[0].toInteger()

                    if (code >= 500)
                        allowRetry = true
                    else if (code >= 400)
                        forceNotify = true

                } catch (Exception ignore) {}
            }
        }

        // -------------------------------------------------
        // AUTH ERRORS
        // -------------------------------------------------
        else if (
            exMsg?.contains("401") ||
            exMsg?.contains("403") ||
            exMsg?.contains("unauthorized") ||
            exMsg?.contains("forbidden")
        ) {
            forceNotify = true
            forceTicket = true
        }

        // -------------------------------------------------
        // PERMANENT ERRORS (SCRIPT / MAPPING / LOGIC)
        // -------------------------------------------------
        else {

            boolean isPermanent =
                    exClass?.contains("method") ||
                    exClass?.contains("mapping") ||
                    exClass?.contains("script") ||
                    exClass?.contains("nullpointer") ||
                    exClass?.contains("illegalargument") ||
                    exMsg?.contains("validation") ||
                    exMsg?.contains("parse")

            if (isPermanent) {
                forceNotify  = true
                forceTicket  = true
                forcePersist = true
            }
            else {
                // Default fallback
                forceNotify = true
            }
        }
    }

    // =====================================================
    // 4. FINAL DECISION LOGIC
    // =====================================================

    boolean finalRetry = devRetry && allowRetry
    boolean finalNotify = devNotify || forceNotify || !finalRetry
    boolean finalTicket = devTicket || forceTicket || !finalRetry
    boolean finalPersist = devPersist || forcePersist || !finalRetry

    // =====================================================
    // 5. STORE FINAL FLAGS
    // =====================================================
    message.setProperty("IsRetry",   finalRetry)
    message.setProperty("IsNotify",  finalNotify)
    message.setProperty("IsTicket",  finalTicket)
    message.setProperty("IsPersist", finalPersist)

    return message
}