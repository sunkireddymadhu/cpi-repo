import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.util.UUID
import java.time.Instant

def Message processData(Message message) {

    def p = message.getProperties()

    // Generate Persist ID
    String persistId = UUID.randomUUID().toString()

    // Read raw exception
    String rawException = p.get("Exception") ?: ""

    String shortMsg = rawException

    // Extract meaningful error message
    if(rawException.contains("No signature of method")){
        shortMsg = rawException.substring(rawException.indexOf("No signature of method"))
    }
    else if(rawException.contains(":")){
        shortMsg = rawException.substring(rawException.indexOf(":") + 1).trim()
    }

    // Remove CPI internal object reference
    shortMsg = shortMsg.replaceAll(/\[com\.sap\..*?\]/, "")

    // Remove Groovy engine prefix
    shortMsg = shortMsg.replaceAll(/org\.codehaus\.groovy\..*?processData\(\)/, "processData()")

    shortMsg = shortMsg.trim()

    // Detect exception type
    String exceptionType = "Unknown"

    if(rawException.contains("NoSuchMethodException") || rawException.contains("No signature of method")){
        exceptionType = "GroovyNoSuchMethodException"
    }
    else if(rawException.contains("NullPointerException")){
        exceptionType = "NullPointerException"
    }
    else if(rawException.contains("Timeout")){
        exceptionType = "TimeoutException"
    }
    else if(rawException.contains("SSL")){
        exceptionType = "SSLException"
    }
    else if(rawException.contains("Connection")){
        exceptionType = "ConnectionException"
    }
    else if(rawException.contains("Mapping")){
        exceptionType = "MappingException"
    }

    // Handle payload
    def payloadObj = p.get("OriginalPayload")

    try{
        payloadObj = new JsonSlurper().parseText(payloadObj)
    }
    catch(Exception e){
        // XML or plain text → keep as is
    }

    // Persist object
    def obj = [
        persistId : persistId,
        interfaceId : p.get("Interface_ID"),
        correlationId : p.get("CorrelationId"),
        errorCategory : p.get("ErrorCategory"),
        severity : p.get("ErrorSeverity"),
        timestamp : Instant.now().toString(),
        status : "NEW",
        retryCount : 0,

        exception : [
            type : exceptionType,
            message : shortMsg,
            rootCause : shortMsg
        ],

        rawException : rawException,
        payload : payloadObj
    ]

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(obj)))

    return message
}