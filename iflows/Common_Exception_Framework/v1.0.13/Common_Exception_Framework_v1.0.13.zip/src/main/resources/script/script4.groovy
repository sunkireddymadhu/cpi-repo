import groovy.json.JsonOutput
import com.sap.gateway.ip.core.customdev.util.Message
def Message processData(Message message) {

    def props = message.getProperties()
    def originalPayload = message.getBody(String)

    def correlationId = message.getHeader("CorrelationId", String)

    def errorPayload = [
        interfaceName : props.InterfaceName,
        correlationId : correlationId,
        errorType     : props.ErrorType,
        errorClass    : props.ErrorClass,
        errorMessage  : props.ErrorMessage,
        payload       : originalPayload,
        timestamp     : new Date().format("yyyy-MM-dd'T'HH:mm:ss")
    ]

    message.setProperty("CorrelationId", correlationId)
    message.setBody(JsonOutput.toJson(errorPayload))
    message.setHeader("Content-Type", "application/json")

    return message
}
