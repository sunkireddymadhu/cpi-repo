import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def props = message.getProperties()

    // Read exception message captured earlier
    String error = props.get("ExceptionMessage") ?: ""
    error = error.toLowerCase()

    String category = "UNKNOWN"
    String severity = "MEDIUM"

    boolean retryAllowed = false
    boolean scriptError = false
    boolean connectivityError = false

    // =========================
    // SCRIPT / DEVELOPMENT ERRORS
    // =========================
    if (
        error.contains("groovy") ||
        error.contains("nosuchmethod") ||
        error.contains("missingmethod") ||
        error.contains("nullpointer") ||
        error.contains("illegalargument")
    ) {

        category = "SCRIPT_ERROR"
        severity = "CRITICAL"

        scriptError = true
        retryAllowed = false
    }

    // =========================
    // CONNECTIVITY ERRORS
    // =========================
    else if (
        error.contains("timeout") ||
        error.contains("connect") ||
        error.contains("connection") ||
        error.contains("ssl") ||
        error.contains("unknownhost") ||
        error.contains("refused")
    ) {

        category = "CONNECTIVITY"
        severity = "HIGH"

        connectivityError = true
        retryAllowed = true
    }

    // =========================
    // HTTP ERRORS
    // =========================
    else if (
        error.contains("404") ||
        error.contains("403") ||
        error.contains("401")
    ) {

        category = "AUTHORIZATION"
        severity = "HIGH"
        retryAllowed = false
    }

    else if (
        error.contains("500") ||
        error.contains("502") ||
        error.contains("503")
    ) {

        category = "REMOTE_SYSTEM"
        severity = "HIGH"
        retryAllowed = true
    }

    // =========================
    // DATA / VALIDATION ERRORS
    // =========================
    else if (
        error.contains("validation") ||
        error.contains("mapping") ||
        error.contains("parsing")
    ) {

        category = "DATA_ERROR"
        severity = "MEDIUM"
        retryAllowed = false
    }

    // =========================
    // DEFAULT SYSTEM ERROR
    // =========================
    else {

        category = "SYSTEM"
        severity = "MEDIUM"
        retryAllowed = true
    }

    // Set framework properties
    message.setProperty("ErrorCategory", category)
    message.setProperty("ErrorSeverity", severity)

    message.setProperty("FW_RetryAllowed", retryAllowed)
    message.setProperty("IsScriptError", scriptError)
    message.setProperty("IsConnectivityError", connectivityError)

    return message
}