import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {

    // Read headers with datatype
    def correlationId = message.getHeader("CorrelationID", String.class)
    def errorId = message.getHeader("ErrorID", String.class)
    def errorTimestamp = message.getHeader("ErrorTimestamp", String.class)
    def exception = message.getHeader("Exception", String.class)
    def interfaceId = message.getHeader("Interface_ID", String.class)

    // Create JSON structure
    def bodyMap = [
        CorrelationID : correlationId,
        ErrorID : errorId,
        ErrorTimestamp : errorTimestamp,
        Exception : exception,
        Interface_ID : interfaceId
    ]

    def jsonBody = JsonOutput.prettyPrint(JsonOutput.toJson(bodyMap))

    message.setBody(jsonBody)

    return message
}