import com.sap.gateway.ip.core.customdev.util.Message
import java.util.UUID
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def props = message.getProperties()

    if (!props.get("CorrelationID"))
        message.setProperty("CorrelationID", UUID.randomUUID().toString())

    message.setProperty("ErrorID", UUID.randomUUID().toString())

    def sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
    message.setProperty("ErrorTimestamp", sdf.format(new Date()))

    message.setProperty("FlowName", props.get("CamelContextName"))

    int retryCount = (props.get("RetryCount") ?: 0) as int
    message.setProperty("RetryAttempt", retryCount)

    return message
}