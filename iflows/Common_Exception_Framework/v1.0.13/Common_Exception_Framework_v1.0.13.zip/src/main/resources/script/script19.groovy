import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import groovy.json.JsonSlurper
import java.time.Instant
import java.time.OffsetDateTime

def Message processData(Message message) {

    def p = message.getProperties()

    String interfaceId = p.get("Interface_ID") ?: "UNKNOWN_INTERFACE"
    String correlationId = p.get("CorrelationId") ?: java.util.UUID.randomUUID().toString()

    String persistId = interfaceId + "_" + correlationId

    // ✅ IMPORTANT (for DataStore Write)
    message.setProperty("persistId", persistId)

    String replayEndpoint = p.get("ReplayEndpoint") ?: ""

    if(replayEndpoint.startsWith("http://")){
        replayEndpoint = replayEndpoint.replaceFirst("http://","https://")
    }

    String rawException = p.get("Exception") ?: ""
    String shortMsg = rawException

    if(rawException.contains("No signature of method")){
        shortMsg = rawException.substring(rawException.indexOf("No signature of method"))
    } else if(rawException.contains(":")){
        shortMsg = rawException.substring(rawException.indexOf(":") + 1).trim()
    }

    shortMsg = shortMsg.replaceAll(/\[com\.sap\..*?\]/, "")
    shortMsg = shortMsg.replaceAll(/org\.codehaus\.groovy\..*?processData\(\)/, "processData()")
    shortMsg = shortMsg.trim()

    String exceptionType = "Unknown"

    if(rawException.contains("NoSuchMethodException") || rawException.contains("No signature of method")){
        exceptionType = "GroovyNoSuchMethodException"
    } else if(rawException.contains("NullPointerException")){
        exceptionType = "NullPointerException"
    }

    def payloadObj = p.get("OriginalPayload")

    if(payloadObj == null || payloadObj.toString().trim().isEmpty()){
        payloadObj = message.getBody(String)
    }

    try{
        payloadObj = new JsonSlurper().parseText(payloadObj)
    } catch(Exception e){}

    // ✅ Generate timestamp
    String timestamp = Instant.now().toString()

    // ✅ NEW: Extract messageDate (YYYY-MM-DD)
    String messageDate = OffsetDateTime.parse(timestamp).toLocalDate().toString()

    def obj = [
        persistId : persistId,
        interfaceId : interfaceId,
        correlationId : correlationId,
        replayEndpoint : replayEndpoint,
        errorCategory : p.get("ErrorCategory"),
        severity : p.get("ErrorSeverity"),
        timestamp : timestamp,
        messageDate : messageDate,   // ✅ NEW FIELD
        status : "NEW",
        retryCount : 0,
        exception : [
            type : exceptionType,
            message : shortMsg,
            rootCause : shortMsg
        ],
        rawException : rawException,
        payload : payloadObj
    ]

    message.setBody(JsonOutput.toJson(obj))

    return message
}