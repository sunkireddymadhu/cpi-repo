import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // GET EXCEPTION SAFELY
    def ex =
            message.getProperty("CamelExceptionCaught") ?:
            message.getHeader("CamelExceptionCaught", Object) ?:
            message.getProperty("Exception")

    String full = ""

    if (ex != null) {
        def current = ex
        int depth = 0

        while (current != null && depth < 15) {
            full += current.toString() + " | "
            current = current.getCause()
            depth++
        }
    }

    full = full.toLowerCase()

    String category = "UNKNOWN"
    boolean scriptError = false
    boolean retryAllowed = false

    // SCRIPT ERROR DETECTION
    if (
        full.contains("groovy") ||
        full.contains("nosuchmethod") ||
        full.contains("missingmethod") ||
        full.contains("nullpointer")
    ) {
        category = "SCRIPT_ERROR"
        scriptError = true
        retryAllowed = false
    }

    // CONNECTIVITY
    else if (
        full.contains("timeout") ||
        full.contains("connect") ||
        full.contains("ssl") ||
        full.contains("unknownhost")
    ) {
        category = "CONNECTIVITY"
        retryAllowed = true
    }

    else {
        category = "SYSTEM"
        retryAllowed = true
    }

    message.setProperty("ErrorCategory", category)
    message.setProperty("IsScriptError", scriptError)
    message.setProperty("FW_RetryAllowed", retryAllowed)

    return message
}