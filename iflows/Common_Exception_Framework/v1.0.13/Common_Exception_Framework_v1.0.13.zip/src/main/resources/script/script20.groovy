import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    message.setBody("""
<Incident>
    <short_description>This is INT001 Exception</short_description>
    <assignment_group>dev_user</assignment_group>
</Incident>
""")

    return message
}