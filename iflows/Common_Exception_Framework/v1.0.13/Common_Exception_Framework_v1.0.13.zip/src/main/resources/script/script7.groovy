import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def headers = message.getHeaders()
    def props   = message.getProperties()

    // =====================================================
    // 1. INTERFACE ID
    // =====================================================
    def interfaceId = (props.get("Interface_ID") ?: "DEFAULT").toString()
    message.setProperty("Interface_ID", interfaceId)

    // =====================================================
    // 2. BOOLEAN CONVERTER
    // =====================================================
    def toBool = { val ->
        return val != null && val.toString().trim().equalsIgnoreCase("true")
    }

    // =====================================================
    // 3. FLAG READER (Property → Header → Default)
    // =====================================================
    def readFlag = { name, defaultVal ->
        def val = props.get(name)
        if (val == null) {
            val = headers.get(name)
        }
        return val != null ? toBool(val) : defaultVal
    }

    // =====================================================
    // 4. INITIAL FLAGS
    // =====================================================
    def isRetry   = readFlag("IsRetry",   true)
    def isNotify  = readFlag("IsNotify",  false)
    def isTicket  = readFlag("IsTicket",  false)
    def isPersist = readFlag("IsPersist", false)

    // =====================================================
    // 5. RETRY CONFIG
    // =====================================================
    int maxRetries = 3
    try {
        maxRetries = (props.get("MaxRetry") ?: 3).toString().toInteger()
    } catch(Exception e){}

    def retryHeader = headers.get("CTX_RetryCount")

    int currentCount = 0
    try {
        currentCount = retryHeader ? retryHeader.toString().toInteger() : 0
    } catch(Exception e){
        currentCount = 0
    }

    // =====================================================
    // 6. ERROR CLASSIFICATION ENGINE
    // =====================================================
    def ex = props.get("CamelExceptionCaught")
    def exClass = ex?.getClass()?.getName()
    def exMsg   = ex?.getMessage()?.toLowerCase()

    Integer status = null

    if (ex != null) {

        // ---------- HTTP STATUS DETECTION ----------
        def httpCode = props.get("CamelHttpResponseCode")

        if(httpCode){
            try {
                status = httpCode.toString().toInteger()
            } catch(Exception ignore){}
        }
        else if(exClass?.contains("HttpOperationFailedException")){
            def m = (exMsg =~ /\b\d{3}\b/)
            if(m){
                try{
                    status = m[0].toInteger()
                }catch(Exception ignore){}
            }
        }

        // ---------- HTTP CLASSIFICATION ----------
        if(status != null){

            if(status >= 500){
                isRetry = true
                isNotify = false
            }
            else if(status >= 400){
                isRetry = false
                isNotify = true
            }
        }

        // ---------- SCRIPT FAILURE ----------
        else if(exClass?.contains("Groovy")){
            isRetry = false
            isNotify = true
            isTicket = true
        }

        // ---------- TIMEOUT / NETWORK ----------
        else if(exClass?.contains("SocketTimeout") ||
                exClass?.contains("ConnectException") ||
                exMsg?.contains("timeout") ||
                exMsg?.contains("connection")){

            isRetry = true
        }

        // ---------- AUTH ERRORS ----------
        else if(exMsg?.contains("unauthorized") ||
                exMsg?.contains("forbidden") ||
                exMsg?.contains("401") ||
                exMsg?.contains("403")){

            isRetry = false
            isNotify = true
            isTicket = true
        }

        // ---------- MAPPING ERRORS ----------
        else if(exClass?.contains("Mapping") ||
                exMsg?.contains("mapping") ||
                exMsg?.contains("parse")){

            isRetry = false
            isNotify = true
            isTicket = true
            isPersist = true
        }

        // ---------- ADAPTER CONNECTION FAILURES ----------
        else if(exClass?.contains("HttpHostConnectException") ||
                exClass?.contains("UnknownHostException") ||
                exClass?.contains("SSLException")){

            isRetry = true
        }

        // ---------- DEFAULT ----------
        else{
            isRetry = false
            isNotify = true
        }
    }

    // =====================================================
    // 7. RETRY LIMIT CHECK
    // =====================================================
    if(currentCount >= maxRetries){
        isRetry = false
        isNotify = true
        message.setHeader("IsFinalFailure", "true")
    }
    else{
        message.setHeader("CTX_RetryCount", currentCount + 1)
    }

    // =====================================================
    // 8. STORE FINAL FLAGS
    // =====================================================
    message.setProperty("IsRetry", isRetry)
    message.setProperty("IsNotify", isNotify)
    message.setProperty("IsTicket", isTicket)
    message.setProperty("IsPersist", isPersist)

    return message
}