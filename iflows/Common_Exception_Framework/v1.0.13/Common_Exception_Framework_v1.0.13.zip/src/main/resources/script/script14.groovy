import com.sap.gateway.ip.core.customdev.util.Message
import java.util.UUID
import java.text.SimpleDateFormat

def Message processData(Message message) {

    def props = message.getProperties()

    // Flow Name
    def flowName = props.get("CamelContextName")
    message.setProperty("FlowName", flowName)

    // Retry Count
    int retry = (props.get("RetryCount") ?: 0) as int
    message.setProperty("RetryCount", retry)

    // Correlation ID
    if (!props.get("CorrelationID"))
        message.setProperty("CorrelationID", UUID.randomUUID().toString())

    // Timestamp
    def sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    message.setProperty("ErrorTimestamp", sdf.format(new Date()))

    // Extract Exception Text
    def ex = message.getProperty("CamelExceptionCaught")

    String err = ""
    def cur = ex
    int depth = 0
    while (cur != null && depth < 10) {
        err += cur.toString() + "\n"
        cur = cur.getCause()
        depth++
    }

    message.setProperty("ExceptionMessage", err)

    // Payload Snapshot
    def body = message.getBody(String)
    if (body)
        message.setProperty("PayloadSnippet", body.take(1000))

    return message
}