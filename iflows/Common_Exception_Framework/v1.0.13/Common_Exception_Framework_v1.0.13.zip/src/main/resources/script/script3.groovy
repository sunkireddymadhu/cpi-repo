import com.sap.gateway.ip.core.customdev.util.Message

def processData(message) {

    def ex = message.getProperties().get("CamelExceptionCaught")

    message.setProperty("ErrorMessage", ex?.getMessage() ?: "Unknown Error")
    message.setProperty("ErrorClass", ex?.getClass()?.getName())

    return message
}


