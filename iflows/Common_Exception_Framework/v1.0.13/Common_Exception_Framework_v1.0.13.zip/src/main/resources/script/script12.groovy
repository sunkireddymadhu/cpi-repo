import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def connectivity = message.getProperty("IsConnectivityError")
    def scriptError  = message.getProperty("IsScriptError")

    int retry = (message.getProperty("RetryCount") ?: 0) as int
    int max   = (message.getProperty("MaxRetry") ?: 3) as int

    boolean fwRetry   = false
    boolean fwNotify  = true
    boolean fwTicket  = true
    boolean fwPersist = true

    if (scriptError) {
        fwRetry = false
    }
    else if (connectivity && retry < max) {
        fwRetry = true
        fwNotify = false
        fwTicket = false
        fwPersist = false
        message.setProperty("RetryCount", retry + 1)
    }

    message.setProperty("FW_IsRetry", fwRetry)
    message.setProperty("FW_IsNotify", fwNotify)
    message.setProperty("FW_IsTicket", fwTicket)
    message.setProperty("FW_IsPersist", fwPersist)

    return message
}