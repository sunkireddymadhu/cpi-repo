import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.ITApiFactory
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.util.UUID

def processData(message) {

    // 1️⃣ Parse original payload (assume JSON)
    def originalPayload = message.getBody(String)
    def json = [:]
    try {
        json = new JsonSlurper().parseText(originalPayload)
    } catch (Exception e) {
        // payload is not JSON, leave empty map
    }

    // 2️⃣ Ensure InterfaceName
    def interfaceName = json.interfaceName ?: message.getProperty("InterfaceName") ?: "DefaultInterface"
    message.setProperty("InterfaceName", interfaceName)

    // 3️⃣ Ensure CorrelationId (safe UUID fallback)
    def correlationId = message.getHeader("CorrelationId", String) 
                        ?: message.getProperty("CamelMessageId") 
                        ?: UUID.randomUUID().toString()
    message.setProperty("CorrelationId", correlationId)

    // 4️⃣ Error details (safe defaults)
    def props = message.getProperties()
    def errorMessage = props.ErrorMessage ?: "Unknown Error"
    def errorClass   = props.ErrorClass ?: "Unknown"
    def errorType    = props.ErrorType ?: "Unknown"

    message.setProperty("ErrorMessage", errorMessage)
    message.setProperty("ErrorClass", errorClass)
    message.setProperty("ErrorType", errorType)

    // 5️⃣ Value Mapping API
    def vmApi = ITApiFactory.getApi(ValueMappingApi.class, null)

    // List of mapping keys
    def mappings = ["IsNotify", "IsRetry", "IsIncident", "IsPersist"]

    // Fetch mappings safely and convert to boolean
    mappings.each { mapKey ->
        def rawValue = vmApi.getMappedValue("CPI", interfaceName, "CSF", mapKey, "false")
        def boolValue = (rawValue ?: "").toLowerCase() == "true"
        message.setProperty(mapKey, boolValue)
    }

    // 6️⃣ Build JSON payload for logging / error handling
    def errorPayload = [
        interfaceName : interfaceName,
        correlationId : correlationId,
        errorType     : errorType,
        errorClass    : errorClass,
        errorMessage  : errorMessage,
        payload       : originalPayload,
        timestamp     : new Date().format("yyyy-MM-dd'T'HH:mm:ss")
    ]

    message.setBody(JsonOutput.toJson(errorPayload))
    message.setHeader("Content-Type", "application/json")

    // 7️⃣ Optional: log routing properties
    println "Routing Properties: IsIncident=${message.getProperty("IsIncident")}, " +
            "IsNotify=${message.getProperty("IsNotify")}, " +
            "IsRetry=${message.getProperty("IsRetry")}, " +
            "IsPersist=${message.getProperty("IsPersist")}"

    return message
}
