import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // =====================================================
    // 1. EXTRACT ROOT CAUSE
    // =====================================================
    def ex = message.getProperty("CamelExceptionCaught")

    def root = ex
    int depth = 0
    while (root?.getCause() != null && depth < 10) {
        root = root.getCause()
        depth++
    }

    def exClass = root?.getClass()?.getName()?.toLowerCase()
    def exMsg   = root?.getMessage()?.toLowerCase()

    // =====================================================
    // 2. RETRY COUNTER MANAGEMENT
    // =====================================================
    int retryCount = (message.getProperty("RetryCount") ?: 0) as int
    int maxRetry   = (message.getProperty("MaxRetry") ?: 3) as int

    // =====================================================
    // 3. CLASSIFICATION FLAGS
    // =====================================================
    boolean isScriptError = false
    boolean isConnectivityError = false
    String errorCategory = "UNKNOWN"
    String severity = "MEDIUM"

    if (root != null) {

        // ---------------------------------------------
        // SCRIPT / PERMANENT ERRORS
        // ---------------------------------------------
        isScriptError =
                exClass?.contains("groovy") ||
                exClass?.contains("script") ||
                exClass?.contains("method") ||
                exClass?.contains("nullpointer") ||
                exClass?.contains("illegalargument") ||
                exMsg?.contains("nosuchmethod") ||
                exMsg?.contains("missingmethod")

        if (isScriptError) {
            errorCategory = "SCRIPT_ERROR"
            severity = "CRITICAL"
        }

        // ---------------------------------------------
        // CONNECTIVITY ERRORS
        // ---------------------------------------------
        else if (
            exClass?.contains("timeout") ||
            exClass?.contains("connect") ||
            exClass?.contains("unknownhost") ||
            exClass?.contains("ssl") ||
            exMsg?.contains("timeout") ||
            exMsg?.contains("connection")
        ) {
            isConnectivityError = true
            errorCategory = "CONNECTIVITY"
            severity = "HIGH"
        }

        // ---------------------------------------------
        // OTHER ERRORS
        // ---------------------------------------------
        else {
            errorCategory = "FUNCTIONAL_OR_SYSTEM"
            severity = "HIGH"
        }
    }

    // =====================================================
    // 4. DECISION LOGIC
    // =====================================================

    boolean finalRetry   = false
    boolean finalNotify  = true
    boolean finalTicket  = true
    boolean finalPersist = true

    // -----------------------------------------------------
    // SCRIPT ERRORS → NEVER RETRY (FORCED)
    // -----------------------------------------------------
    if (isScriptError) {

        finalRetry = false

    }
    // -----------------------------------------------------
    // CONNECTIVITY ERRORS → RETRY WITH LIMIT
    // -----------------------------------------------------
    else if (isConnectivityError) {

        if (retryCount < maxRetry) {
            finalRetry = true
            retryCount++
            finalNotify = false
            finalTicket = false
            finalPersist = false
        } else {
            finalRetry = false
        }
    }
    // -----------------------------------------------------
    // ALL OTHER ERRORS → NO RETRY
    // -----------------------------------------------------
    else {
        finalRetry = false
    }

    // =====================================================
    // 5. STORE PROPERTIES
    // =====================================================
    message.setProperty("IsRetry", finalRetry)
    message.setProperty("IsNotify", finalNotify)
    message.setProperty("IsTicket", finalTicket)
    message.setProperty("IsPersist", finalPersist)

    message.setProperty("RetryCount", retryCount)
    message.setProperty("MaxRetry", maxRetry)

    message.setProperty("ErrorCategory", errorCategory)
    message.setProperty("ErrorSeverity", severity)

    return message
}