import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def p = message.getProperties()

    def finalRetry =
        p.get("FW_IsRetry") == false
            ? false
            : (p.get("IsRetry") != null ? p.get("IsRetry") : p.get("FW_IsRetry"))

    def finalNotify  = p.get("IsNotify")  != null ? p.get("IsNotify")  : p.get("FW_IsNotify")
    def finalTicket  = p.get("IsTicket")  != null ? p.get("IsTicket")  : p.get("FW_IsTicket")
    def finalPersist = p.get("IsPersist") != null ? p.get("IsPersist") : p.get("FW_IsPersist")

    message.setProperty("IsRetry", finalRetry)
    message.setProperty("IsNotify", finalNotify)
    message.setProperty("IsTicket", finalTicket)
    message.setProperty("IsPersist", finalPersist)

    return message
}