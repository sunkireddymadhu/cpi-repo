import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def ex = message.getProperty("CamelExceptionCaught")

    if(ex != null){

        message.setProperty("ExceptionType", ex.getClass().getName())
        message.setProperty("ExceptionMessage", ex.getMessage())

        def root = ex
        while(root?.cause != null){
            root = root.cause
        }

        message.setProperty("RootCause", root?.getMessage())
    }

    return message
}