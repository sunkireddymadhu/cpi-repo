import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {

    def tenantURL = message.getHeader("CamelHttpUrl", String)
    def interfaceID = message.getHeader("CamelServletContextPath", String)
    def correlationId = message.getHeader("CorrelationId", String)
    def exception = message.getHeader("Exception", String)
    def exceptionStack = message.getHeader("ExceptionStack", String)

    def desc = """Interface ID : ${interfaceID}
Correlation ID : ${correlationId}
Tenant URL : ${tenantURL}
Exception : ${exception}

Stack Trace :
${exceptionStack}
"""

    def payload = [
        short_description : "SAP CPI Interface Failure - " + interfaceID,
        description : desc
    ]

    message.setBody(JsonOutput.toJson(payload))
    message.setHeader("Content-Type", "application/json")

    return message
}