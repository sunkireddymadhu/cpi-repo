import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {

    def results = message.getProperty("results")

    def finalResponse = [results: results]

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(finalResponse)))

    return message
}