import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def interfaceId = json.interfaceId
    def correlationIds = json.correlationIds ?: []

    def lines = []

    correlationIds.each { id ->
        lines.add(interfaceId + "_" + id)
    }

    // Convert to line-separated string
    message.setBody(lines.join("\n"))

    return message
}