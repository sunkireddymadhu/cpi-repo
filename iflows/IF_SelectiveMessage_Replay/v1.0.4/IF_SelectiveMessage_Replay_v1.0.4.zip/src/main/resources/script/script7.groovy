import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {

    def agg = message.getProperty("agg")

    def results = []

    agg.split("###").each { part ->

        def clean = part?.trim()

        if(clean && clean.startsWith("{")) {
            try {
                results.add(new JsonSlurper().parseText(clean))
            } catch(Exception e) {
                // ignore bad JSON safely
            }
        }
    }

    def finalResponse = [results: results]

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(finalResponse)))
    message.setHeader("Content-Type", "application/json")

    return message
}