import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {

    def body = message.getBody(String)

    def results = []

    // 🔥 Split JSON objects properly (no newline case)
    def parts = body.split("(?=\\{)")

    parts.each { part ->

        def clean = part?.trim()

        if(clean && clean.startsWith("{")) {
            try {
                results.add(new JsonSlurper().parseText(clean))
            } catch(Exception e) {}
        }
    }

    def finalResponse = [results: results]

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(finalResponse)))
    message.setHeader("Content-Type", "application/json")

    return message
}