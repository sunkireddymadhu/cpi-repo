import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def current = message.getBody(String)

    def agg = message.getProperty("agg")
    if(agg == null) agg = ""

    agg = agg + current + "###"

    message.setProperty("agg", agg)

    return message
}