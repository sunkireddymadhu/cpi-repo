import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def body = message.getBody(String)

    // Append newline → enables aggregation
    message.setBody(body + "\n")

    return message
}