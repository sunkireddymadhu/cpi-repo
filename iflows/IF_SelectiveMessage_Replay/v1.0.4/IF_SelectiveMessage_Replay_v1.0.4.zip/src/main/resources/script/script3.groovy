import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.*

def Message processData(Message message) {

    def results = []

    message.getBody(String).split("\n").each { line ->
        if(line?.trim()){
            results.add(new JsonSlurper().parseText(line))
        }
    }

    def finalResponse = [results: results]

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(finalResponse)))

    return message
}