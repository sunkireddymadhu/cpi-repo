import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def body = message.getBody(String)

    // Parse JSON
    def json = new JsonSlurper().parseText(body)

    def persistId = json.persistId

    // ✅ Build filtered JSON (only required fields)
    def filtered = [
        persistId     : json.persistId,
        interfaceId   : json.interfaceId,
        correlationId : json.correlationId,
        messageDate   : json.messageDate,
        exceptionType : json.exception?.type
    ]

    def filteredJson = JsonOutput.toJson(filtered)

    // ✅ Build XML with filtered payload
    def xml = """
<root>
    <persistId>${persistId}</persistId>
    <payload><![CDATA[${filteredJson}]]></payload>
</root>
"""

    message.setBody(xml.trim())
    message.setHeader("Content-Type", "application/xml")

    return message
}