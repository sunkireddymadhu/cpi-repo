import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def body = message.getBody(String)

    if (body) {

        def json = new JsonSlurper().parseText(body)

        // ✅ Extract MessageDate (YYYY-MM-DD)
        def messageDate = ""
        if (json.timestamp) {
            messageDate = json.timestamp.split("T")[0]
        }

        // ✅ Extract only required fields
        def filtered = [
            persistId      : json.persistId,
            interfaceId    : json.interfaceId,
            correlationId  : json.correlationId,
            replayEndpoint : json.replayEndpoint,
            timestamp      : json.timestamp,
            messageDate    : messageDate,   // ✅ NEW FIELD
            status         : json.status,
            exceptionType  : json.exception?.type,
            payload        : json.payload
        ]

        // ✅ Set properties (for filtering / routing later)
        message.setProperty("persistId", filtered.persistId)
        message.setProperty("interfaceId", filtered.interfaceId)
        message.setProperty("correlationId", filtered.correlationId)
        message.setProperty("status", filtered.status)
        message.setProperty("messageDate", messageDate)  // ✅ IMPORTANT

        // ✅ Set filtered JSON as body
        message.setBody(JsonOutput.toJson(filtered))
    }

    return message
}