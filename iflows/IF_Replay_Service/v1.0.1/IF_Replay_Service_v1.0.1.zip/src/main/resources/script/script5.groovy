import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def original = message.getProperty("originalRecord")

    if(original == null || original.toString().trim().isEmpty()){
        return message
    }

    def json = new JsonSlurper().parseText(original)

    // Convert payload map to JSON string
    def payload = JsonOutput.toJson(json.payload)

    message.setBody(payload)

    return message
}