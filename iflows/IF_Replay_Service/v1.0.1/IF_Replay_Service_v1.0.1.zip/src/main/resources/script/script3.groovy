import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def persistData = message.getProperty("persistData")

    def payload = persistData.payload

    message.setBody(JsonOutput.toJson(payload))

    return message
}