import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    def interfaceId = json.interfaceId
    def correlationIds = json.correlationIds

    if (!interfaceId || !correlationIds || correlationIds.isEmpty()) {
        throw new Exception("interfaceId or correlationIds missing")
    }

    // Create list of objects for splitter
    def list = correlationIds.collect { cid ->
        [
            interfaceId   : interfaceId,
            correlationId : cid
        ]
    }

    message.setBody(JsonOutput.toJson(list))

    return message
}