import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.util.XmlSlurper

def Message processData(Message message){

    def body = message.getBody(String)

    if(body == null || body.trim().isEmpty()){
        message.setProperty("status","NOT_FOUND")
        return message
    }

    def jsonText = body

    // If datastore returns XML wrapper
    if(body.trim().startsWith("<")){
        def xml = new XmlSlurper().parseText(body)
        jsonText = xml.data.text()
    }

    message.setProperty("originalRecord", jsonText)

    def json = new JsonSlurper().parseText(jsonText)

    message.setProperty("status", json.status)
    message.setProperty("persistId", json.persistId)
    message.setProperty("interfaceId", json.interfaceId)
    message.setProperty("correlationId", json.correlationId)
    message.setProperty("ReplayEndpoint", json.replayEndpoint)

    return message
}