import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // Get headers
    def headers = message.getHeaders()
    def persistId = headers.get("persistid")
    def host = headers.get("host")

    if(persistId){

        // Extract interfaceId (before underscore)
        def interfaceId = persistId.split("_")[0]

        // Save interfaceId as property
        message.setProperty("interfaceId", interfaceId)

        // Build dynamic URL
        def url = "https://" + host + "/http/" + interfaceId

        // Set dynamic HTTP endpoint
        message.setHeader("CamelHttpUri", url)
    }

    return message
}