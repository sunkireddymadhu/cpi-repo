import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def originalRecord = message.getProperty("originalRecord")

    if(originalRecord == null || originalRecord.toString().trim().isEmpty()){
        return message
    }

    def json = new JsonSlurper().parseText(originalRecord)

    // Get the real CPI exception
    def exception = message.getProperty("CamelExceptionCaught")

    def errorMessage = ""

    if(exception != null){
        errorMessage = exception.getMessage()
    }

    // Update datastore record
    json.status = "FAILED"
    json.replayError = errorMessage

    def updatedRecord = JsonOutput.prettyPrint(JsonOutput.toJson(json))

    message.setBody(updatedRecord)
    message.setProperty("updatedRecord", updatedRecord)

    // Response for Postman
    def response = [
        message : "Replay failed: ${errorMessage}",
        interfaceId : json.interfaceId,
        correlationId : json.correlationId,
        status : "FAILED",
    ]

    message.setProperty("replayResponse",
        JsonOutput.prettyPrint(JsonOutput.toJson(response)))

    return message
}