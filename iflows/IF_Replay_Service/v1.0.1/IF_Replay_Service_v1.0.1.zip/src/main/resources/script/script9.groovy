import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

def Message processData(Message message) {

    def persistId = message.getHeader("persistId")
    def status = "SUCCESS"
    def errorMsg = ""

    def ex = message.getProperty("CamelExceptionCaught")
    if(ex != null){
        status = "FAILED"
        errorMsg = ex.getMessage()
    }

    def result = [
        persistId: persistId,
        status: status,
        error: errorMsg
    ]

    message.setBody(JsonOutput.toJson(result))

    return message
}