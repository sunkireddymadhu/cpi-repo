import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {

    def body = message.getBody(String)

    def json = new JsonSlurper().parseText(body)

    message.setProperty("persistData", json)
    message.setProperty("retryCount", json.retryCount ?: 0)

    return message
}