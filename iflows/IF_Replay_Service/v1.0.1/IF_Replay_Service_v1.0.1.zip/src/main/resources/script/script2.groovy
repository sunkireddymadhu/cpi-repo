import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message){

    def original = message.getProperty("originalRecord")

    if(original == null || original.toString().trim().isEmpty()){
        return message
    }

    def json = new JsonSlurper().parseText(original)

    // Update datastore status
    json.status = "REPLAYED"

    def updatedRecord = JsonOutput.prettyPrint(JsonOutput.toJson(json))

    // Store updated record for datastore update
    message.setProperty("updatedRecord", updatedRecord)

    // Prepare Postman response separately
    def response = [
        message : "Message has been replayed successfully",
        interfaceId : json.interfaceId,
        correlationId : json.correlationId,
        status : "REPLAYED"
    ]

    message.setProperty("replayResponse",
        JsonOutput.prettyPrint(JsonOutput.toJson(response)))

    return message
}