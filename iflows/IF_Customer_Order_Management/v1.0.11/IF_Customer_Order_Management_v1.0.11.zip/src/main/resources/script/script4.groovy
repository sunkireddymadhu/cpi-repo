import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def ex = message.getProperty("CamelExceptionCaught")
    def rootCause = ex?.cause ?: ex

    def retryCount = (message.getProperty("RetryCount") ?: 0) as Integer

    def errorMap = [
        ErrorMessage   : rootCause?.message,
        ErrorType      : rootCause?.class?.name,
        ErrorTimestamp : new Date().toString(),
        HttpStatusCode : message.getProperty("CamelHttpResponseCode"),
        CorrelationId  : message.getHeaders()?.get("SAP_MessageProcessingLogID")
    ]

    // Set normalized error payload
    message.setBody(errorMap)

    // Initialize control properties
    message.setProperty("RetryCount", retryCount)
    message.setProperty("SendNotification", false)
    message.setProperty("CreateIncident", false)
    message.setProperty("AllowRetry", false)

    return message
}
