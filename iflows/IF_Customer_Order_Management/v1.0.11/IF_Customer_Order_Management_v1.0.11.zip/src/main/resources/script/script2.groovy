/* 
 Common Error Flow – Error Context Builder
*/

import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput

Message processData(Message message) {

    // Read exchange properties
    def props = message.getProperties()

    def errorMsg        = props.get("ErrorMessage") ?: "Unknown error"
   // def interfaceId     = props.get("IntegrationFlow") ?: "UnknownFlow"
    def timeStamp       = props.get("Timestamp") ?: ""
   // def tenantURL       = props.get("TenantURL") ?: ""
    def isIncident      = props.get("IsIncident") ?: false
    def isNotification  = props.get("IsNotification") ?: false
    def mplId           = props.get("SAP_MessageProcessingLogID")

    // Build common error object
    def errorContext = [
       // interfaceId    : interfaceId,
        //tenantURL      : tenantURL,
        timestamp      : timeStamp,
        mplId          : mplId,
        errorMessage   : errorMsg,
        isIncident     : isIncident,
        isNotification : isNotification
    ]

    // Convert to JSON and set as body
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(errorContext)))

    return message
}
