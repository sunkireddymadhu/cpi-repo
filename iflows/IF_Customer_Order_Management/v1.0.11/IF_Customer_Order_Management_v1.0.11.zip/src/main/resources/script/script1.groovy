import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message procssData(Message message) {

    def body = message.getBody(java.io.Reader)   // ✅ String
    def json = new JsonSlurper().parse(body)

    def num1 = json.num1 as Integer
    def num2 = json.num2 as Integer

    def sum = num1 + num2
    message.setBody("Sum is ${sum}")

    return message
}
