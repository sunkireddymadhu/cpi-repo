import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    String Payload = message.getBody(String)

    message.setProperty("OriginalPayload", Payload)

    return message
}