import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def properties = message.getProperties()
    def errorMsg = properties.get("ErrorMessage")
    
    // LOGIC: Set Tenant URL (e.g., hardcoded or from a map)
    message.setProperty("p_TenantUrl", "https://my-tenant.com")
    
    // LOGIC: Determine flags based on error content
    if (errorMsg.contains("Critical")) {
        message.setProperty("IsNotify", "true")
        message.setProperty("IsIncident", "true")
    } else {
        message.setProperty("IsNotify", "false") // Just log it
        message.setProperty("IsIncident", "false")
    }
    
    return message
}