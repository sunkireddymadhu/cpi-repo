import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def body = message.getBody(String)

    // Debug
    messageLogFactory.getMessageLog(message)?.addAttachmentAsString("RAW_BODY", body, "text/plain")

    return message
}