import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlSlurper
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.time.OffsetDateTime

def Message processData(Message message) {

    def body = message.getBody(String)

    def interfaceId = message.getProperty("interfaceId")
    def fromDate = message.getProperty("fromDate")
    def toDate = message.getProperty("toDate")

    def xml = new XmlSlurper().parseText(body)

    def result = []

    xml.entry.each { entry ->

        def jsonText = entry.text()

        if(jsonText){

            def data = new JsonSlurper().parseText(jsonText)

            // Filter by interfaceId
            if(data.interfaceId == interfaceId){

                boolean withinRange = true

                if(fromDate && toDate){
                    def ts = OffsetDateTime.parse(data.timestamp)
                    def from = OffsetDateTime.parse(fromDate)
                    def to = OffsetDateTime.parse(toDate)

                    withinRange = (ts.isAfter(from) && ts.isBefore(to))
                }

                if(withinRange){
                    result.add([
                        persistId     : data.persistId,
                        interfaceId   : data.interfaceId,
                        correlationId : data.correlationId,
                        timestamp     : data.timestamp,
                        exception     : data.exception?.message
                    ])
                }
            }
        }
    }

    message.setBody(JsonOutput.toJson(result))

    // VERY IMPORTANT
    message.setHeader("Content-Type", "application/json")

    return message
}