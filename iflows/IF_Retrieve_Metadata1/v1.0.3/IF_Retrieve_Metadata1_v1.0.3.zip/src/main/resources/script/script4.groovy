import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def body = message.getBody(String)
    def messageDate = message.getProperty("messageDate")

    def xml = new XmlSlurper().parseText(body)

    def result = []

    xml.message.each { msg ->

        def jsonStr = msg.root.payload.text()

        if (jsonStr) {
            def json = new JsonSlurper().parseText(jsonStr)

            if (json.messageDate == messageDate) {

                // ✅ Remove persistId
                json.remove("persistId")

                result.add(json)
            }
        }
    }

    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(result)))

    return message
}