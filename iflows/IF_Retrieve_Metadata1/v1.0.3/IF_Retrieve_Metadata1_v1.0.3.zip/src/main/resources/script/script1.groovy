import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    // ✅ Read query parameters from headers
    def interfaceId = message.getHeader("interfaceId", String)
    def messageDate = message.getHeader("messageDate", String)

    // ✅ Validation (important)
    if (!interfaceId || !messageDate) {
        throw new Exception("Missing required query parameters: interfaceId or messageDate")
    }

    // ✅ Set as properties (for later use)
    message.setProperty("interfaceId", interfaceId)
    message.setProperty("messageDate", messageDate)

    return message
}