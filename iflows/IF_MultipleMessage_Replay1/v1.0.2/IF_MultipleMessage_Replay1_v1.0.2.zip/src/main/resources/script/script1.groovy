import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput

def Message processData(Message message) {

    def body = message.getBody(String)

    if (!body || body.trim().isEmpty()) {
        throw new Exception("Empty DataStore response")
    }

    // ✅ No import needed for XmlSlurper
    def xml = new XmlSlurper().parseText(body)

    def resultList = []

    xml.message.each { msg ->

        def root = msg.root

        def persistId = root.persistId.text()
        def jsonString = root.payload.text()

        if (jsonString && jsonString.trim()) {

            def json = new JsonSlurper().parseText(jsonString)

            resultList.add([
                persistId     : persistId,
                interfaceId   : json.interfaceId,
                correlationId : json.correlationId,
                retryCount    : json.retryCount,
                status        : json.status,
                payload       : json.payload
            ])
        }
    }

    message.setBody(JsonOutput.toJson(resultList))

    return message
}